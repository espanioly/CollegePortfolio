#include <stdio.h>
/* Author: Sam Espanioly */
int main(void)
	{
	printf("\nHello. My name is Sam Espanioly.\n");
	}
